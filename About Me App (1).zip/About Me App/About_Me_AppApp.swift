//
//  About_Me_AppApp.swift
//  About Me App
//
//  Created by scholar on 8/10/23.
//

import SwiftUI

          @main
struct About_Me_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
